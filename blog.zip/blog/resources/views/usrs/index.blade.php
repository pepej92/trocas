<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<a href="{{route('usrs.create')}}">Novo Usuario</a><br>

	@foreach ($usrs as $usr)

	<h3>{{$usr->nome}}</h3>
	
	<a href="{{route('usrs.show',[$usr->id])}}">Mostrar</a><br>

	<a href="{{route('usrs.edit',[$usr->id])}}">Editar</a><br><br>

	<form action="{{route('usrs.destroy',[$usr->id])}}" method="POST">
		@method('DELETE')
		@csrf

		<input type="submit" value="Remover"></input>
	</form>
	
	@endforeach
</body>
</html>