<!DOCTYPE html>
<html>
<head>
	<title>Usuario: {{ $usrs->nome }}</title>
</head>
<body>

	<h1>Usuario - Detalhes</h1>
	<label>Usuario</label>:{{ $usrs->nome }}
	<br>
	<label>Email</label>:{{ $usrs->email }}
	<br>
	<label>Senha</label>:{{$usrs->senha}}
	<br>
	<a href="{{route('usrs.index')}}">voltar</a>

</body>
</html>