<!DOCTYPE html>
<html>
<head>
	<title>
		Editar Informações: {{$usrs->nome}}
	</title>
</head>
<body>

	<h1>Editar Informações</h1>

	<form action="{{route('usrs.update', ['id' => $usrs->id])}}" method="POST">
		{{ csrf_field() }}
		{{ method_field('PUT') }}
		
		<label>Nome</label>
		<input type="text" name="nome" 
			value="{{$usrs->nome}}">
		<label>Senha</label>
		<input type="text" name="senha" 
			value="{{$usrs->senha}}">
		<button>Enviar</button>
	</form>

	<a href={{ route('usrs.index') }}>voltar</a>
</body>
</html>