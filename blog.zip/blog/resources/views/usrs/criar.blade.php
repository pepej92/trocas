<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form method="POST" action="{{route('usrs.store')}}">
		
		{{csrf_field()}}	

		<h1>Cadastrar Usuario</h1> 

		<label>Nome:</label>
		<input type="text" name="nome">
		<br>

		<label>Email:</label>
		<input type="text" name="email">
		<br>

		<label>Senha:</label>
		<input type="number" name="senha">
		<br>
		<input type="submit">
	</form>
</body>
</html>