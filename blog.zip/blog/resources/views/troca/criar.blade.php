<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form method="POST" action="{{route('serv.store')}}">
		
		{{csrf_field()}}	

		<h1>Cadastrar novo serviço</h1> 

		<label>Nome:</label>
		<input type="text" name="nome">
		<br>

		<label>Descricao:</label>
		<input type="text" name="desc">
		<br>

		<label>Id do usuário responsável:</label>
		<input type="number" name="id_usr">
		<br>
		<input type="submit">
	</form>
</body>
</html> 