<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8"/>
		<title>Dá que te dou outra</title>
	</head>
	<body bgcolor="#87CEEB" >
		<center>
			<h1><b>Cadastrar</b></h1>
			Nome:<br>
			<input type="text" name="nome">
			<br>
			Nome de usuário:<br>
			<input type="text" name="usuario">
			<br>
			Email:<br>
			<input type="email" name="emailuser">
			<br>
			Profissão:<br>
			<input type="text" name="prof">
			<br>
			Descrição:<br>
			<input type="text" name="Descricao">
			<br>
			Senha:<br>
			<input type="text" name="senha">
			<br><br>
			<a href = "{{ route('login') }}"><button>Cadastrar</button></a>
		</center>

	</body>
</html>