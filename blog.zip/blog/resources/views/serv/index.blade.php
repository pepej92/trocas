<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<a href="{{route('serv.create')}}">Novo Serviço</a><br>

	@foreach ($serv as $src)

	<h3>{{$src->nome}}</h3>
	
	<a href="{{route('serv.show',[$src->id])}}">Mostrar</a><br><br>

	<form action="{{route('serv.destroy',[$src->id])}}" method="POST">
		@method('DELETE')
		@csrf

		<input type="submit" value="Remover"></input>
	</form>
	
	@endforeach
</body>
</html>