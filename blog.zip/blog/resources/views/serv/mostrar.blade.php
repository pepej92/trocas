<!DOCTYPE html>
<html>
<head>
	<title>Serviço: {{ $serv->nome }}</title>
</head>
<body>

	<h1>Servico - Detalhes</h1>
	<label>Serviço</label>:{{ $serv->nome }}
	<br>
	<label>Descricao</label>:{{ $serv->descricao }}
	<br>
	<label>Id do usuário responsável pelo serviço</label>:{{$serv->id_usr}}
	<br>
	<a href="{{route('serv.index')}}">voltar</a>

</body>
</html>