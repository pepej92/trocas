<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class exemploController extends Controller
{
    public function retornaIndex()
    {
        return view('index');
    }
}
