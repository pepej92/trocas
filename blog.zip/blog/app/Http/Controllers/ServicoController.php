<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use DB;

class ServicoController extends Controller
{

    public function index()
    {
        $serv = DB::select('select * from servicos');
        return view('serv.index',['serv' => $serv]);
    }


    public function create()
    {
        return view('serv.criar');
    }


    public function store(Request $request)
    {
        $nome = Input::get('nome');

        $descricao = Input::get('desc'); 

        $id_usr = Input::get('id_usr');

        DB::insert('insert into servicos (nome,descricao,id_usr) values (?,?,?)',[$nome,$descricao,$id_usr]);

        return redirect()->to(route('serv.index'));
    }



    public function show($id)
    {
        $serv = DB::table('servicos')
            ->where('id',$id)
            ->first();

        if (isset($serv)){
            return view('serv.mostrar',['serv' => $serv]);
        }
        return redirect()->to (route('serv.index'));
    }


  //Decidimos não colocar a opção de editar em serviço visto que caso o serviço  do usuario mude ou seja acrescentado ele pode criar um novo ou deletar um anterior


    public function destroy($id)
    {
        $res = DB::table('servicos')
            ->where('id',$id)
            ->delete();

            return redirect()->to (route('serv.index'));
    }
}
