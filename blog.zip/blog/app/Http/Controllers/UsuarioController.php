<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use DB;

class UsuarioController extends Controller
{

    public function index()
    {
        $usrs = DB::select('select * from usuarios');
        return view('usrs.index',['usrs' => $usrs]);
    }


    public function create()
    {
        return view('usrs.criar');
    }


    public function store(Request $request)
    {
        $nome = Input::get('nome');

        $email = Input::get('email'); 

        $senha = Input::get('senha');

        DB::insert('insert into usuarios (nome,email,senha) values (?,?,?)',[$nome,$email,$senha]);

        return redirect()->to(route('usrs.index'));
    }



    public function show($id)
    {
        $usrs = DB::table('usuarios')
            ->where('id',$id)
            ->first();

        if (isset($usrs)){
            return view('usrs.mostrar',['usrs' => $usrs]);
        }
        return redirect()->to (route('usrs.index'));
    }


    public function edit($id)
    {
        $res = DB::table('usuarios')
            ->where('id',$id)
            ->first();

        if (isset($res)){
            return view('usrs.edit',['usrs' => $res]);
        }
        return redirect()->to (route('usrs.index'));
    }



    public function update(Request $request, $id)
    {
        $nome = Input::get('nome');
        $senha = Input::get('senha');

        //optamos por não alterar o email do usuário, pois caso um cracker invadisse sua conta e alterasse o email, não havería maneiras de recurperar a conta roubada

        DB::table('usuarios')
            ->where('id',$id)
            ->update(['nome' => $nome,
            'senha' => $senha]);

        return redirect()->to (route('usrs.index'));

    }



    public function destroy($id)
    {
        $res = DB::table('usuarios')
            ->where('id',$id)
            ->delete();

            return redirect()->to (route('usrs.index'));
    }
}
