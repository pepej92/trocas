<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class gerenciadorController extends Controller
{
    public function cadastrar(){    	
    	return view('cadastrar');
    }

    public function login(){    	
    	return view('login');
    }

    public function solicitar(){    	
    	return view('solicitar');
    }

    public function index(){    	
    	return view('index');
    }

    public function telaprincipal(){    	
    	return view('telaprincipal');
    }

    public function visualizar(){    	
    	return view('visualizar');
    }
}
