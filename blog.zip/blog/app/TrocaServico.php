<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TrocaServico extends Model
{
    public function servicos(){
    	return $this->belongsTo(Servico::class,'id'); 
    }
}
