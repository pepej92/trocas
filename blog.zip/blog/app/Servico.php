<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Servico extends Model
{
    public $timestamps = false;

    public function usuario(){
    	return $this->belongsTo(Usuario::class,'id');
    }

    public function trocaservico(){
    	return $this->hasMany(TrocaServico::class,'serv_sol');
    }
}
