<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Usuario extends Model
{
	public $timestamps = false;
	
    public function servicos(){
    	return $this->hasMany(Servico::class,'id_usr'); 
    }
}
