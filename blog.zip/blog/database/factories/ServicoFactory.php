<?php

use Faker\Generator as Faker;

$factory->define(App\Servico::class, function (Faker $faker) {
     
	$nomes = [
	'limpar', 
	'cozinhar',
	'consertar',
	'animar',
	'construir',
	'programar'
	];


     return [
        'nome' => $nomes[rand(0,5)],
        'descricao' => "frase aleatoria"
    ];
});
