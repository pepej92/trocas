<?php

use Faker\Generator as Faker;

$factory->define(TrocaServico::class, function (Faker $faker) {
    return [
    	'nome' => $faker->name,
    	'email' => $faker->unique()->safeEmail,
        'senha' => 123
    ];

    $table->unsignedInteger('id_usr1')->nullable();
    $table->unsignedInteger('serv_sol')->nullable();
    $table->unsignedInteger('id_usr2')->nullable();
    $table->unsignedInteger('serv_dese')->nullable();
});
