<?php

use Illuminate\Database\Seeder;

class ServicoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        factory(App\Servico::class,10)
        ->create()
        ->each(function($obj){
            $v = rand(1,App\Usuario::count());
            $obj->id_usr = App\Usuario::find($v) -> id;
            $obj->save();
        });
    }
}
