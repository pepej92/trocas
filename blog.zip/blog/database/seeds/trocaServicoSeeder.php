<?php

use Illuminate\Database\Seeder;

class trocaServicoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        for ($i = 0; $i < 3; $i++) {

            $serv_sol = App\Servico::all()
        		->random(1);

        	do {
			    $serv_dese = App\Servico::all()
        		->random(1);
			} while ($serv_dese == $serv_sol);

            DB::table('troca_servicos')->insert([
                'serv_sol' => $serv_sol[0]->id,
                'id_usr1' => $serv_sol[0]->id_usr,
                'serv_dese' => $serv_dese[0]->id,
                'id_usr2' => $serv_dese[0]->id_usr
                
            ]);    
        }

    }
}
