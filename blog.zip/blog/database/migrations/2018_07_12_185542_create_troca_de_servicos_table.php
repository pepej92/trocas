<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTrocaDeServicosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('troca_de_servicos', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('usuario1_id')->unsigned();
            $table->integer('usuario2_id')->unsigned();
            $table->integer('servico_id')->unsigned();
            $table->string('descricao');
            $table->foreign('usuario1_id')
                ->references('id')->on('usuarios');
            $table->foreign('servico_id')
                ->references('id')->on('servicos');  
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('troca_de_servicos');
    }
}
