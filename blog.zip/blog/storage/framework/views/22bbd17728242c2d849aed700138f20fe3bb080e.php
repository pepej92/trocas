<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<a href="<?php echo e(route('serv.create')); ?>">Novo Serviço</a><br>

	<?php $__currentLoopData = $serv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $src): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

	<h3><?php echo e($src->nome); ?></h3>
	
	<a href="<?php echo e(route('serv.show',[$src->id])); ?>">Mostrar</a><br><br>

	<form action="<?php echo e(route('serv.destroy',[$src->id])); ?>" method="POST">
		<?php echo method_field('DELETE'); ?>
		<?php echo csrf_field(); ?>

		<input type="submit" value="Remover"></input>
	</form>
	
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html>