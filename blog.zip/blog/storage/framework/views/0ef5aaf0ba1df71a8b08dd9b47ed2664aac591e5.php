<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8"/>
		<title>Dá que te dou outra</title>
	</head>
	<body bgcolor="#87CEEB" >
		<center>
			<h1><b>Dá que te dou outra</b></h1>
			<img  width="400px" height="300px"  src = "inic.jpg"><br/>
			<a href = "<?php echo e(route('login')); ?>"><button>Login</button>
			<a href = "<?php echo e(route('cadastrar')); ?>"><button>Cadastre-se</button>


		</center>

	</body>
</html>