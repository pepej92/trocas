<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8"/>
		<title>Dá que te dou outra</title>
	</head>
	<body bgcolor="#87CEEB" >
		<center>
			<h1><b>Login</b></h1>
			Usuário:<br>
			<input type="text" name="usuario">
			<br>
			Senha:<br>
			<input type="text" name="senha">
			<br><br>
			<a href = "<?php echo e(route('telaprincipal')); ?>"><button>Entrar</button></a>
		</center>

	</body>
</html>