<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8"/>
		<title>Dá que te dou outra</title>
	</head>
	<body bgcolor="#87CEEB" >
		<center>
			<h1><b>Solicitar serviço</b></h1>
			Área:<br>
			<input placeholder = "digite a área desejada" type="text" name="area">
			<br>
			<button>Pesquisar</button>
		</center>

	</body>
</html>