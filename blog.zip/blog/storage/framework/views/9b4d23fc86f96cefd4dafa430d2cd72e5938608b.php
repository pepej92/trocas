<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8"/>
		<title>Dá que te dou outra</title>
	</head>
	<body bgcolor="#87CEEB" >
		<center>
			<h1><b>Central de serviços</b></h1>
		
		<h3>Você pode:</h3><br>
		<a href = "<?php echo e(route('solicitar')); ?>"><button>Solicitar serviço</button></a>
		<br><br>
		ou<br>
		<br>
		<a href = "<?php echo e(route('visualizar')); ?>"><button>Visualizar serviços</button></a>
		</center>
		

	</body>
</html>