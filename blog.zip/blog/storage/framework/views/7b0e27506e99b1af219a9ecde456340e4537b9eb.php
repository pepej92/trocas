<!DOCTYPE html>
<html>
<head>
	<title>Usuario: <?php echo e($usrs->nome); ?></title>
</head>
<body>

	<h1>Usuario - Detalhes</h1>
	<label>Usuario</label>:<?php echo e($usrs->nome); ?>

	<br>
	<label>Email</label>:<?php echo e($usrs->email); ?>

	<br>
	<label>Senha</label>:<?php echo e($usrs->senha); ?>

	<br>
	<a href="<?php echo e(route('usrs.index')); ?>">voltar</a>

</body>
</html>