<!DOCTYPE html>
<html>
<head>
	<title>
		Editar Informações: <?php echo e($usrs->nome); ?>

	</title>
</head>
<body>

	<h1>Editar Informações</h1>

	<form action="<?php echo e(route('usrs.update', ['id' => $usrs->id])); ?>" method="POST">
		<?php echo e(csrf_field()); ?>

		<?php echo e(method_field('PUT')); ?>

		
		<label>Nome</label>
		<input type="text" name="nome" 
			value="<?php echo e($usrs->nome); ?>">
		<label>Senha</label>
		<input type="text" name="senha" 
			value="<?php echo e($usrs->senha); ?>">
		<button>Enviar</button>
	</form>

	<a href=<?php echo e(route('usrs.index')); ?>>voltar</a>
</body>
</html>