<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<a href="<?php echo e(route('usrs.create')); ?>">Novo Usuario</a><br>

	<?php $__currentLoopData = $usrs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

	<h3><?php echo e($usr->nome); ?></h3>
	
	<a href="<?php echo e(route('usrs.show',[$usr->id])); ?>">Mostrar</a><br>

	<a href="<?php echo e(route('usrs.edit',[$usr->id])); ?>">Editar</a><br><br>

	<form action="<?php echo e(route('usrs.destroy',[$usr->id])); ?>" method="POST">
		<?php echo method_field('DELETE'); ?>
		<?php echo csrf_field(); ?>

		<input type="submit" value="Remover"></input>
	</form>
	
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html>