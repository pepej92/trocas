<!DOCTYPE html>
<html>
<head>
	<title>Serviço: <?php echo e($serv->nome); ?></title>
</head>
<body>

	<h1>Servico - Detalhes</h1>
	<label>Serviço</label>:<?php echo e($serv->nome); ?>

	<br>
	<label>Descricao</label>:<?php echo e($serv->descricao); ?>

	<br>
	<label>Id do usuário responsável pelo serviço</label>:<?php echo e($serv->id_usr); ?>

	<br>
	<a href="<?php echo e(route('serv.index')); ?>">voltar</a>

</body>
</html>