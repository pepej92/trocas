<?php


Route::get('/','gerenciadorController@index')->name('index');

Route::get('/cadastrar','gerenciadorController@cadastrar')->name('cadastrar');

Route::get('/login','gerenciadorController@login')->name('login');

Route::get('/telaprincipal','gerenciadorController@telaprincipal')->name('telaprincipal');

Route::get('/solicitar','gerenciadorController@solicitar')->name('solicitar');

Route::get('/visualizar','gerenciadorController@visualizar')->name('visualizar');
