<?php

Route::resource('usrs', 'UsuarioController');

Route::resource('serv', 'ServicoController');

